# 导入必要的库
import copy

import networkx as nx

import sys

def networkx(filename):
    """--------------------------------------------------------------------------------
                 function:       把一个含有边的txt数据集表示成networkx
                 Parameters:     filename：文件名称 .txt格式
                 Returns：       G：表示成networkx的图
                ---------------------------------------------------------------------------------"""
    fin = open(filename, 'r')
    G = nx.Graph()
    for line in fin:
        data = line.split()
        if data[0] != '#':
            G.add_edge(int(data[0]), int(data[1]))
    return G

# 读取G.txt文件，并创建一个图对象
def read_txt_file(file_path):
    G = nx.Graph()
    with open(file_path, 'r') as file:
        for line in file:
            source, target = line.strip().split()
            G.add_edge(source, target)
    return G

# 从CSV文件中读取社区数据
def read_community_csv(file_path):
    community_data = {}
    id = 0
    with open(file_path, 'r') as file:
        for line in file:
            fields = line.strip().split(',')  # 假设字段之间使用逗号分隔
            for node in fields:
                if node not in community_data.keys():
                    community_data[node] = id
            id += 1
    return community_data


# 将图保存为.gml文件
def save_gml_file(G, community_data, output_file):
    for node, community in community_data.items():
        if len(node)>0:
            G.nodes[node]['community'] = community
    nx.write_gml(G, output_file)

if __name__ == "__main__":

    # datasets = ["SEP", "HIE", "SNP", "PEP"]
    # datasets = ["BBC4view_685", "UCI_mfeat"]
    # datasets = ["football"]
    # for dataset in datasets:
    #     input_file = f"E:\CoIM论文相关\CoIM\MNLCD_python\dataset\\toGml\{dataset}\G.txt"
    #     output_file = f"E:\CoIM论文相关\CoIM\MNLCD_python\dataset\\toGml\{dataset}\{dataset}Ggml.gml"
    #     community_file = f"E:\CoIM论文相关\CoIM\MNLCD_python\dataset\\toGml\{dataset}\groundTruth.csv"
    #
    #     # 读取G.txt文件并创建图对象
    #     graph = read_txt_file(input_file)
    #
    #     # 从CSV文件中读取社区数据
    #     community_data = read_community_csv(community_file)
    #     print(community_data)
    #     # 保存图为.gml文件，同时将社区信息添加到节点属性中
    #     save_gml_file(graph, community_data, output_file)
    #
    #     print(f"Converted {input_file} and community data to {output_file}")
    dataset = 'lj'
    comindex = 0
    output_file = f"./{dataset}/{comindex}{dataset}_d.gml"
    with open(f'./{dataset}/{dataset}-1.90.cmty.txt') as fh:
        comms = fh.read().strip().split('\n')
        comms = [[int(i) for i in x.split()] for x in comms]
    G = networkx(f"./{dataset}/{dataset}-1.90.ungraph.txt")
    com = comms[comindex]
    # com = [305048, 299865, 253193, 233096, 305047, 20409, 102137, 102214, 132895, 49294, 49296, 46399, 49293, 90210, 49291, 90207, 102202, 90517, 82568, 102119, 102020, 49297, 102072, 90208, 34968, 250047, 253183, 250471, 250469, 102218, 231718, 5998, 74835, 36509, 204525, 86715, 250470, 101988, 250472, 39776, 102033, 101986, 194922, 20408, 102191, 81134, 49295, 216019, 102121, 20402, 102197, 102122, 102128, 216683]
    print(com)
    neighbors_of_com = set()
    for node in com:
        # neighbors_of_com.update(G.neighbors(node))
        neighbors_of_com.add(node)

    # for node in copy.deepcopy(neighbors_of_com):
    #     neighbors_of_com.update(G.neighbors(node))
    subG = G.subgraph(list(neighbors_of_com))
    # subG = G.subgraph(list(com))
    for node in com:
        G.nodes[node]['community'] = '1'
    nx.write_gml(subG, output_file)
